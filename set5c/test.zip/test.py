print("a" * 10**6)
